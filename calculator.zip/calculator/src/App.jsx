import React from 'react'
import Calcy from './components/Calcy'

function App() {
  return (
    <>
    
    <Calcy />
    
    </>
  )
}

export default App